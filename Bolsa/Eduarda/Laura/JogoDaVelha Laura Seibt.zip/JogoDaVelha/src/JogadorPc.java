
/**
 * Classe para objetos do tipo JogadorPc, onde serao contidos, valores e metodos
 * para o mesmo.
 * 
 * @author liseibt
 */

public class JogadorPc {
	private MapaJogoVelha mapa;
	private char letra;

	/**
	 * Construtor de JogadorPC
	 * 
	 * @param mapa MapaJogoVelha - Objeto de mapa do jogo da velha.
	 */
	public JogadorPc(MapaJogoVelha mapa) {
		setMapa(mapa);
		setLetra('O');
	}

	/**
	 * Metodo para sorteio da jogada do JogadorPc de acordo com a linha e coluna.
	 * Caso valida, a jogada é efetuada, caso contrario o sorteio da jogada eh
	 * repetido até ser valido.
	 * 
	 * @return boolean - jogada feita.
	 */
	public boolean joga() {
		boolean jogadaValida = false;
		int linha = 0;
		int coluna = 0;
		while (!jogadaValida) {
			linha = mapa.sortear(0, 3);
			coluna = mapa.sortear(0, 3);

			if (mapa.jogar(linha, coluna, letra)) {
				mapa.jogar(linha, coluna, letra);
				jogadaValida = true;
			}
		}
		System.out.println("PC[" + linha + "," + coluna + "]");
		return true;
	}

	/**
	 * Metodo para retorno do mapa do jogo da velha.
	 * 
	 * @return MapaJogoVelha mapa - Objeto de mapa do jogo da velha.
	 */
	public MapaJogoVelha getMapa() {
		return mapa;
	}

	/**
	 * Metodo set do mapa do jogo da velha.
	 * 
	 * @param mapa MapaJogoVelha - Objeto de mapa do jogo da velha.
	 */
	public void setMapa(MapaJogoVelha mapa) {
		this.mapa = mapa;
	}

	/**
	 * Metodo para retorno da letra jogada pelo JogadorPc.
	 * 
	 * @return char - letra para a jogada do JogadorPc.
	 */
	public char getLetra() {
		return letra;
	}

	/**
	 * Metodo set para a letra do JogadorPc.
	 * 
	 * @param letra int - Letra para a jogada do JogadorPc.
	 */
	public void setLetra(char letra) {
		this.letra = letra;
	}
}
