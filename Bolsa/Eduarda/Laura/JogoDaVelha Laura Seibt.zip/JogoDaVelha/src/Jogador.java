import java.util.Scanner;

/**
 * Classe para objetos do tipo jogador, onde serao contidos, valores e metodos
 * para o mesmo.
 * 
 * @author liseibt
 */

public class Jogador {
	private MapaJogoVelha mapa;
	private char letra;

	/**
	 * Construtor de Jogador.
	 * 
	 * @param mapa MapaJogoVelha - Objeto de mapa do jogo da velha.
	 */
	public Jogador(MapaJogoVelha mapa) {
		setMapa(mapa);
		setLetra('X');
	}

	/**
	 * Metodo para jogada do Jogador de acordo com a linha e coluna. Caso valida a
	 * jogada eh efetuada, caso contrario a jogada eh repetida ate ser valida.
	 * 
	 * @param teclado - Input do Jogador.
	 * @return boolean - Jogada feita.
	 */
	public boolean joga(Scanner teclado) {
		boolean jogadaValida = false;
		while (!jogadaValida) {
			System.out.print("Linha:  ");
			int linha = teclado.nextInt();
			System.out.print("Coluna: ");
			int coluna = teclado.nextInt();
			if (mapa.jogar(linha, coluna, letra)) {
				mapa.jogar(linha, coluna, letra);
				jogadaValida = true;
			} else {
				System.out.println("Célula inválida!");
			}
		}
		return true;
	}

	/**
	 * Metodo para retorno da letra jogada pelo Jogador.
	 * 
	 * @return char - letra para a jogada do Jogador.
	 */
	public char getLetra() {
		return letra;
	}

	/**
	 * Metodo set para a letra do Jogador.
	 * 
	 * @param letra int - Letra para a jogada do Jogador.
	 */
	public void setLetra(char letra) {
		this.letra = letra;
	}

	/**
	 * Metodo para retorno do mapa do jogo da velha.
	 * 
	 * @return MapaJogoVelha mapa - Objeto de mapa do jogo da velha.
	 */
	public MapaJogoVelha getMapa() {
		return mapa;
	}

	/**
	 * Metodo set do mapa do jogo da velha.
	 * 
	 * @param mapa MapaJogoVelha - Objeto de mapa do jogo da velha.
	 */
	public void setMapa(MapaJogoVelha mapa) {
		this.mapa = mapa;
	}
}
