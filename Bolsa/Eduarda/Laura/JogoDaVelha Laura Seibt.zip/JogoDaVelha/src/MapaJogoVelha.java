
/**
 * Classe para objetos do tipo MapaJogoVelha, onde serao contidos, valores e
 * metodos para o mesmo.
 * 
 * @author liseibt
 *
 */

public class MapaJogoVelha {

	private char[][] mapa;

	/**
	 * Construtor de MapaJogoVelha.
	 */
	public MapaJogoVelha() {
		mapa = new char[3][3];
	}

	/**
	 * Metodo para sorteio
	 * 
	 * @param inicio int - Valor inteiro inicio.
	 * @param fim    - int - Valor inteiro fim.
	 * @return int - Valor inteiro resultado do sorteio.
	 */
	public int sortear(int inicio, int fim) {
		return (int) (Math.random() * 3);
	}

	/**
	 * Metodo para limpar mapa do jogo da velha alocando ' ' a todos as casas do
	 * mapa.
	 */
	public void limpaMapa() {
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				mapa[i][j] = ' ';
			}
		}
	}

	/**
	 * Metodo para desenhar o jogo da velha no console.
	 * 
	 * @param jogada int - Jogada do Jogador ou JogadorPc.
	 * @param acabou boolean - Valor boolean que verifica se o jogo acabou.
	 */
	public void desenha(int jogada, boolean acabou) {
		System.out.println("---------------");
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				if (j < 2)
					System.out.print("| " + mapa[i][j] + " |");
				else
					System.out.println("| " + mapa[i][j] + " |");
			}
			System.out.println("---------------");
		}
		if (jogada != 0 && !acabou)
			System.out.print("Jogada " + jogada + ": ");
	}

	/**
	 * Metodo que verifica se a linha e colunha da jogada é valida (livre). Se for
	 * valida efetua a jogada.
	 * 
	 * @param l       int - Numero da linha do mapa do jogo da velha.
	 * @param c       int - Numero da coluna do mapa do jogo da velha.
	 * @param jogador char - Letra de jogada do Jogador ou do JogadorPc.
	 * @return boolean - valor boolean de a cordo com a jogada feita (true caso a
	 *         jogada for valida e false caso não seja valida).
	 */
	public boolean jogar(int l, int c, char jogador) {
		if ((l >= 0 && l < 3) && (c >= 0 && c < 3))
			if (mapa[l][c] == ' ') {// testa se a célula tá livre
				mapa[l][c] = jogador;
				return true;
			}
		return false;
	}

	/**
	 * Metodo que Verifica se o Jogador ou o JogadorPc ganhou a partida do jogo da
	 * velha.
	 * 
	 * @param jogador char - Letra de jogada do Jogador ou do JogadorPc.
	 * @return boolean - Valor boolean (true se o Jogador ou o JogadorPc ganhou a
	 *         partida).
	 */
	public boolean ganhou(char jogador) {
		for (int i = 0; i < 3; i++) {
			if (mapa[i][0] == jogador && mapa[i][1] == jogador && mapa[i][2] == jogador)
				return true;
			for (int j = 0; j < 3; j++) {
				if (mapa[0][j] == jogador && mapa[1][j] == jogador && mapa[2][j] == jogador)
					return true;
			}
		}
		if (mapa[0][0] == jogador && mapa[1][1] == jogador && mapa[2][2] == jogador)
			return true;
		if (mapa[0][2] == jogador && mapa[1][1] == jogador && mapa[2][0] == jogador)
			return true;

		return false;
	}

	/**
	 * Metodo que verifica se houve um empate na partida do joga da velha.
	 * 
	 * @return boolean - true se houve empate ou false caso contrario.
	 */
	public boolean empatou() {
		boolean empate = true;
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				if (mapa[i][j] == ' ') {
					empate = false;
				}
			}
		}
		return empate;
	}
}
