import java.util.Scanner;

/**classe publica concreta que representa o jogador
 * @author
 * */
public class Jogador {
	
	/**classe privada propriedade de objetos de tipo mapa.*/
	private MapaJogoVelha mapa;
	
	/**propriedade letra a ser inserida.*/
	private char letra;

	/**construtor padrao para o jogador. */
	public Jogador(MapaJogoVelha mapa) {
		setMapa(mapa);
		setLetra('X');
	}
	/** construtor para cada jogada a ser executada*/
	public boolean joga(Scanner teclado) {
		boolean jogadaValida = false;
		
		/**laco de repetiçao para validar a jogada*/
		while (!jogadaValida) {
			
			/** imprime a string e armazena na variavel*/
			System.out.print("Linha:  ");
			int linha = teclado.nextInt();
			System.out.print("Coluna: ");
			
			int coluna = teclado.nextInt();
			
			/**condicao*/
			if (mapa.jogar(linha, coluna, letra)) {
				mapa.jogar(linha, coluna, letra);
				jogadaValida = true;
			} else {
				System.out.println("Célula inválida!");
			}
		}
		/**reorna true
		 * @return true*/
		return true;
	}

	/** Recupera a propriedade Letra.
	 * @return Letra.
	 * */
	public char getLetra() {
		return letra;
	}
	
	/** Configura a propriedade Letra
	 * @param letra
	 * Letra Informada.
	 * */
	public  void setLetra(char letra) {
		this.letra = letra;
	}
	
	/** Recupera a propriedade Mapa.
	 * @return Mapa.
	 * */
	public MapaJogoVelha getMapa() {
		return mapa;
	}

	/** Configura a propriedade Mapa
	 * @param letra
	 * Mapa Informado.
	 * */
	public void setMapa(MapaJogoVelha mapa) {
		this.mapa = mapa;
	}
}
